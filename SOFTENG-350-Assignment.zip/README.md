TODO:
[x] Navigation bar
[x] Hero
[x] Tracker
[x] About
[x] Sponsor wall
[x] Footer
[x] Form modal
[x] Find a better background
[x] Add background to cards